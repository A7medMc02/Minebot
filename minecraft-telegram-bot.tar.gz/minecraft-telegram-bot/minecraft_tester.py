#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
وحدة اختبار الاتصال بسيرفر ماين كرافت
تتيح هذه الوحدة اختبار الاتصال بسيرفر ماين كرافت بدون الحاجة لسيرفر فعلي
"""

import asyncio
import logging
from mcstatus import JavaServer
from mcrcon import MCRcon
import config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MinecraftServerTester:
    def __init__(self, host="localhost", port=25565, rcon_port=25575, rcon_password=""):
        self.host = host
        self.port = port
        self.rcon_port = rcon_port
        self.rcon_password = rcon_password
        
    async def test_server_connection(self):
        """اختبار الاتصال بسيرفر ماين كرافت"""
        try:
            server = JavaServer.lookup(f"{self.host}:{self.port}")
            status = await server.async_status()
            
            return {
                'success': True,
                'online': True,
                'players_online': status.players.online,
                'players_max': status.players.max,
                'players_list': [player.name for player in status.players.sample] if status.players.sample else [],
                'version': status.version.name,
                'motd': status.description,
                'latency': status.latency
            }
        except Exception as e:
            logger.warning(f"لا يمكن الاتصال بالسيرفر: {e}")
            return {
                'success': False,
                'online': False,
                'error': str(e),
                'message': 'السيرفر غير متصل أو غير متاح'
            }
    
    def test_rcon_connection(self):
        """اختبار الاتصال بـ RCON"""
        try:
            with MCRcon(self.host, self.rcon_password, port=self.rcon_port) as mcr:
                response = mcr.command("list")
                return {
                    'success': True,
                    'response': response,
                    'message': 'تم الاتصال بـ RCON بنجاح'
                }
        except Exception as e:
            logger.warning(f"لا يمكن الاتصال بـ RCON: {e}")
            return {
                'success': False,
                'error': str(e),
                'message': 'RCON غير متاح أو كلمة المرور خاطئة'
            }
    
    async def simulate_server_status(self):
        """محاكاة حالة سيرفر للاختبار"""
        return {
            'success': True,
            'online': True,
            'players_online': 2,
            'players_max': 20,
            'players_list': ['Player1', 'Player2'],
            'version': 'Paper 1.20.1',
            'motd': 'مرحباً بكم في سيرفر الاختبار!',
            'latency': 45.2,
            'simulated': True
        }
    
    def simulate_rcon_command(self, command):
        """محاكاة تنفيذ أمر RCON للاختبار"""
        responses = {
            'list': 'There are 2 of a max of 20 players online: Player1, Player2',
            'say': 'تم إرسال الرسالة',
            'time set day': 'Set the time to 1000',
            'weather clear': 'Set the weather to clear',
            'whitelist add': 'Added player to whitelist',
            'whitelist remove': 'Removed player from whitelist'
        }
        
        for cmd, response in responses.items():
            if command.startswith(cmd):
                return {
                    'success': True,
                    'response': response,
                    'simulated': True
                }
        
        return {
            'success': True,
            'response': f'تم تنفيذ الأمر: {command}',
            'simulated': True
        }

async def main():
    """اختبار الوحدة"""
    tester = MinecraftServerTester()
    
    print("🔍 اختبار الاتصال بسيرفر ماين كرافت...")
    
    # اختبار الاتصال بالسيرفر
    server_status = await tester.test_server_connection()
    print(f"📊 حالة السيرفر: {server_status}")
    
    # اختبار RCON
    rcon_status = tester.test_rcon_connection()
    print(f"🔧 حالة RCON: {rcon_status}")
    
    # محاكاة للاختبار
    print("\n🎭 محاكاة حالة السيرفر للاختبار:")
    simulated_status = await tester.simulate_server_status()
    print(f"📊 حالة محاكاة: {simulated_status}")
    
    simulated_command = tester.simulate_rcon_command("list")
    print(f"🔧 أمر محاكاة: {simulated_command}")

if __name__ == '__main__':
    asyncio.run(main())

