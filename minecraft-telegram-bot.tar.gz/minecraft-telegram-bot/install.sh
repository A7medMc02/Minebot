#!/bin/bash

# سكريبت تثبيت وتشغيل بوت تليجرام لماين كرافت
# يقوم هذا السكريبت بتثبيت جميع المتطلبات وإعداد البوت

echo "🤖 مرحباً بك في مثبت بوت تليجرام لماين كرافت"
echo "=================================================="

# التحقق من وجود Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 غير مثبت. يرجى تثبيت Python 3.7 أو أحدث"
    exit 1
fi

echo "✅ تم العثور على Python 3"

# التحقق من وجود pip
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 غير مثبت. يرجى تثبيت pip3"
    exit 1
fi

echo "✅ تم العثور على pip3"

# تثبيت المتطلبات
echo "📦 تثبيت المكتبات المطلوبة..."
pip3 install -r requirements.txt

if [ $? -eq 0 ]; then
    echo "✅ تم تثبيت جميع المكتبات بنجاح"
else
    echo "❌ فشل في تثبيت المكتبات"
    exit 1
fi

# التحقق من وجود ملف .env
if [ ! -f ".env" ]; then
    echo "⚠️  ملف .env غير موجود"
    echo "📝 إنشاء ملف .env من القالب..."
    cp .env.example .env
    echo "✅ تم إنشاء ملف .env"
    echo ""
    echo "🔧 يرجى تحرير ملف .env وإدخال:"
    echo "   - توكن بوت تليجرام"
    echo "   - عنوان سيرفر ماين كرافت"
    echo "   - كلمة مرور RCON"
    echo ""
    echo "ثم شغل السكريبت مرة أخرى"
    exit 0
fi

echo "✅ تم العثور على ملف .env"

# التحقق من التوكن
if grep -q "YOUR_BOT_TOKEN_HERE" .env; then
    echo "⚠️  يرجى تحديث توكن البوت في ملف .env"
    exit 1
fi

echo "✅ تم تكوين التوكن"

# اختبار الاتصال
echo "🔍 اختبار الاتصال بسيرفر ماين كرافت..."
python3 minecraft_tester.py

echo ""
echo "🚀 بدء تشغيل البوت..."
echo "   للإيقاف: اضغط Ctrl+C"
echo "   للتشغيل في الخلفية: استخدم start_bot.sh"
echo ""

# تشغيل البوت
python3 minecraft_bot.py

