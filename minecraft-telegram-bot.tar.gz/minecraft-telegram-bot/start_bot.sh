#!/bin/bash

# سكريبت تشغيل البوت في الخلفية

BOT_DIR="/home/ubuntu/minecraft-telegram-bot"
BOT_SCRIPT="minecraft_bot.py"
PID_FILE="$BOT_DIR/bot.pid"
LOG_FILE="$BOT_DIR/bot.log"

cd "$BOT_DIR"

case "$1" in
    start)
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            if ps -p "$PID" > /dev/null 2>&1; then
                echo "البوت يعمل بالفعل (PID: $PID)"
                exit 1
            else
                rm -f "$PID_FILE"
            fi
        fi
        
        echo "🚀 بدء تشغيل البوت..."
        nohup python3 "$BOT_SCRIPT" > "$LOG_FILE" 2>&1 &
        echo $! > "$PID_FILE"
        echo "✅ تم تشغيل البوت (PID: $(cat $PID_FILE))"
        echo "📝 السجلات: $LOG_FILE"
        ;;
        
    stop)
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            if ps -p "$PID" > /dev/null 2>&1; then
                echo "🛑 إيقاف البوت..."
                kill "$PID"
                rm -f "$PID_FILE"
                echo "✅ تم إيقاف البوت"
            else
                echo "البوت غير يعمل"
                rm -f "$PID_FILE"
            fi
        else
            echo "البوت غير يعمل"
        fi
        ;;
        
    restart)
        $0 stop
        sleep 2
        $0 start
        ;;
        
    status)
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            if ps -p "$PID" > /dev/null 2>&1; then
                echo "✅ البوت يعمل (PID: $PID)"
                echo "📊 استخدام الذاكرة: $(ps -p $PID -o rss= | awk '{print $1/1024 " MB"}')"
                echo "⏱️  وقت التشغيل: $(ps -p $PID -o etime= | tr -d ' ')"
            else
                echo "❌ البوت متوقف"
                rm -f "$PID_FILE"
            fi
        else
            echo "❌ البوت متوقف"
        fi
        ;;
        
    logs)
        if [ -f "$LOG_FILE" ]; then
            tail -f "$LOG_FILE"
        else
            echo "لا توجد سجلات"
        fi
        ;;
        
    *)
        echo "الاستخدام: $0 {start|stop|restart|status|logs}"
        echo ""
        echo "الأوامر:"
        echo "  start   - تشغيل البوت"
        echo "  stop    - إيقاف البوت"
        echo "  restart - إعادة تشغيل البوت"
        echo "  status  - عرض حالة البوت"
        echo "  logs    - عرض السجلات المباشرة"
        exit 1
        ;;
esac

