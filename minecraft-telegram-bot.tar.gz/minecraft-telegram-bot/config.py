# إعدادات بوت تليجرام وسيرفر ماين كرافت
import os
from dotenv import load_dotenv

# تحميل المتغيرات البيئية من ملف .env
load_dotenv()

# إعدادات بوت تليجرام
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '7616945734:AAFqG9CPzO3W4uage45P88US-cBR8wEqh7I')

# إعدادات سيرفر ماين كرافت
MINECRAFT_SERVER_HOST = os.getenv('MINECRAFT_SERVER_HOST', 'localhost')
MINECRAFT_SERVER_PORT = int(os.getenv('MINECRAFT_SERVER_PORT', '25565'))
MINECRAFT_RCON_PORT = int(os.getenv('MINECRAFT_RCON_PORT', '25575'))
MINECRAFT_RCON_PASSWORD = os.getenv('MINECRAFT_RCON_PASSWORD', 'your_rcon_password')

# إعدادات البوت
ALLOWED_USERS = []  # قائمة معرفات المستخدمين المسموح لهم باستخدام البوت (فارغة = الجميع)
ADMIN_USERS = []    # قائمة معرفات المدراء

# رسائل البوت
MESSAGES = {
    'welcome': 'مرحباً! أنا بوت ماين كرافت. يمكنني مساعدتك في إدارة السيرفر.',
    'server_status': 'حالة السيرفر:',
    'server_online': '🟢 السيرفر متصل',
    'server_offline': '🔴 السيرفر غير متصل',
    'players_online': 'اللاعبون المتصلون: {}',
    'no_players': 'لا يوجد لاعبون متصلون',
    'error': 'حدث خطأ: {}',
    'unauthorized': 'غير مسموح لك باستخدام هذا الأمر',
    'command_sent': 'تم إرسال الأمر بنجاح',
    'rcon_error': 'خطأ في الاتصال بـ RCON'
}

